# HMS
Hostel management system containing the hostel allotment system and all the latest notifications required
