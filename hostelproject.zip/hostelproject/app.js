var express = require("express");
var app = express();
app.use(express.static("css"));
app.set("view engine", "ejs");
app.get("/", function(req, res){
	res.render("intropage");
})
app.get("/homepage", function(req, res){
	res.send("we are in the homepage");
})
app.listen(3000, function(){
	console.log("server started");
})